# How to use and start the application 
## Step 1 - clone the repo 
## Step 2 - run "npm i" command in root folder and frontend folder
## Step 3 - run "npm start" in root folder
